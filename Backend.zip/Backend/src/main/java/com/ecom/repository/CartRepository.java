package com.ecom.repository;

import com.ecom.entity.Cart;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface CartRepository extends JpaRepository<Cart, String> {
    Optional<Cart> findByUserId(String userId);

    Optional<Cart> findByUserIdAndStatus(String userId,String status);

    void deleteByUserId(String userId);
}